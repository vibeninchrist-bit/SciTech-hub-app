
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getScienceResponse = async (prompt: string, roomPersona?: string) => {
  const ai = getAI();
  const baseInstruction = "You explain complex scientific concepts in a way that is engaging, accurate, and inspiring. Provide clean plain text responses. Do not use markdown formatting, especially asterisks (*) for bolding or italics. If relevant, suggest a simple experiment or follow-up question. Keep responses concise but information-rich.";
  
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: roomPersona ? `${roomPersona} ${baseInstruction}` : `You are Beni, an expert science and technology guide. ${baseInstruction}`
    }
  });

  const response = await chat.sendMessage({ message: prompt });
  return response.text;
};

export const getSpokenResponse = async (text: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Say naturally and clearly: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

export const getGroundedNews = async (query: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Give me the latest update or interesting breakthrough regarding: ${query}. Summarize it briefly and provide links. Do not use asterisks for formatting.`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Source',
      uri: chunk.web?.uri || '#'
    })) || []
  };
};

export const generateSciVisual = async (concept: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: `A highly detailed, cinematic, scientific visualization of ${concept}. 8k resolution, photorealistic, intricate detail, glowing particles, blueprint-style accents.` }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9"
      }
    }
  });

  let imageUrl = '';
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      break;
    }
  }
  return { imageUrl, explanation: response.text };
};

export const analyzeLabData = async (dataDescription: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this scientific data or experiment observation: ${dataDescription}. Generate a JSON object with: { "title": "string", "labels": ["string"], "values": [number], "analysis": "string" }. Do not include markdown formatting in the strings.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          labels: { type: Type.ARRAY, items: { type: Type.STRING } },
          values: { type: Type.ARRAY, items: { type: Type.NUMBER } },
          analysis: { type: Type.STRING }
        },
        required: ["title", "labels", "values", "analysis"]
      }
    }
  });

  return JSON.parse(response.text);
};
