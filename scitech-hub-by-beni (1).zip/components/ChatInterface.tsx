import React, { useState, useRef, useEffect } from 'react';
import { Message, ChatThread, SCIENCE_ROOMS, ScienceRoom, CommunityPost } from '../types';
import { getScienceResponse, generateSciVisual } from '../services/geminiService';
import { 
  PaperAirplaneIcon, 
  PlusIcon, 
  ClockIcon, 
  TrashIcon, 
  Bars3Icon, 
  XMarkIcon, 
  MicrophoneIcon, 
  PhotoIcon,
  ShareIcon,
  CheckIcon,
  PencilIcon,
  AcademicCapIcon,
  ChevronDownIcon,
  ExclamationTriangleIcon,
  SwatchIcon,
  PencilSquareIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/solid';

const AVAILABLE_AVATARS = ['👨‍🔬', '👩‍🔬', '🤖', '🧬', '⚛️', '🪐', '🧠', '🔬', '🚀', '🧪'];

// High-fidelity Beni Neural Core Icon
const BeniIcon: React.FC<{ color: string; size?: string }> = ({ color, size = "w-12 h-12" }) => {
  // Extracting hex or class-based color info from room colors is tricky, 
  // so we'll map the room glow colors to Beni's core pulse.
  return (
    <div className={`${size} relative flex items-center justify-center animate-in fade-in duration-1000`}>
      {/* Outer Orbital Ring */}
      <svg className="absolute w-full h-full animate-[spin_10s_linear_infinite] opacity-40" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="10 5" className="text-indigo-400" />
      </svg>
      
      {/* Middle Pulse Layer */}
      <div className="absolute inset-2 rounded-full border border-white/20 animate-pulse bg-gradient-to-br from-white/10 to-transparent"></div>
      
      {/* The Core Hexagon */}
      <svg className="w-2/3 h-2/3 relative z-10 drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M50 5L89.5 27.5V72.5L50 95L10.5 72.5V27.5L50 5Z" fill="url(#beniGradient)" stroke="white" strokeWidth="2" strokeLinejoin="round" />
        <circle cx="50" cy="50" r="12" fill="white" className="animate-pulse">
           <animate attributeName="r" values="10;14;10" dur="3s" repeatCount="indefinite" />
        </circle>
        <defs>
          <linearGradient id="beniGradient" x1="50" y1="5" x2="50" y2="95" gradientUnits="userSpaceOnUse">
            <stop stopColor="#6366f1" />
            <stop offset="1" stopColor="#a855f7" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

type UITheme = 'midnight' | 'solstice' | 'event-horizon' | 'biosphere';

interface ThemeConfig {
  bg: string;
  sidebar: string;
  header: string;
  text: string;
  textMuted: string;
  border: string;
  inputBg: string;
  bubbleUser: string;
  bubbleAssistant: string;
  accent: string;
}

const THEMES: Record<UITheme, ThemeConfig> = {
  midnight: {
    bg: 'bg-slate-950',
    sidebar: 'bg-slate-900/90',
    header: 'bg-slate-950/20',
    text: 'text-slate-100',
    textMuted: 'text-slate-500',
    border: 'border-slate-800',
    inputBg: 'bg-slate-900/80',
    bubbleUser: 'bg-slate-800/80',
    bubbleAssistant: 'bg-slate-900/60',
    accent: 'blue'
  },
  solstice: {
    bg: 'bg-slate-50',
    sidebar: 'bg-white/90',
    header: 'bg-white/20',
    text: 'text-slate-900',
    textMuted: 'text-slate-400',
    border: 'border-slate-200',
    inputBg: 'bg-white/80',
    bubbleUser: 'bg-blue-100/80',
    bubbleAssistant: 'bg-white shadow-md',
    accent: 'blue'
  },
  'event-horizon': {
    bg: 'bg-black',
    sidebar: 'bg-black border-r border-slate-900',
    header: 'bg-black/40',
    text: 'text-white',
    textMuted: 'text-slate-700',
    border: 'border-slate-900',
    inputBg: 'bg-zinc-900/50',
    bubbleUser: 'bg-zinc-900',
    bubbleAssistant: 'bg-zinc-950 border border-zinc-800',
    accent: 'purple'
  },
  biosphere: {
    bg: 'bg-[#050a05]',
    sidebar: 'bg-[#081208]/90',
    header: 'bg-[#050a05]/20',
    text: 'text-emerald-50',
    textMuted: 'text-emerald-900/50',
    border: 'border-emerald-900/30',
    inputBg: 'bg-[#0a1a0a]/80',
    bubbleUser: 'bg-emerald-900/40',
    bubbleAssistant: 'bg-[#0a1a0a]/60',
    accent: 'emerald'
  }
};

const ChatInterface: React.FC = () => {
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isDictating, setIsDictating] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [activeRoom, setActiveRoom] = useState<ScienceRoom>(SCIENCE_ROOMS[0]);
  const [currentExpertPersona, setCurrentExpertPersona] = useState(SCIENCE_ROOMS[0].expertPersona);
  const [lastError, setLastError] = useState<string | null>(null);
  const [uiTheme, setUiTheme] = useState<UITheme>('midnight');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Message Editing
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editInput, setEditInput] = useState('');

  // Thread Renaming
  const [renamingThreadId, setRenamingThreadId] = useState<string | null>(null);
  const [renameInput, setRenameInput] = useState('');

  const [userAvatar, setUserAvatar] = useState('👨‍🔬');
  const [userName, setUserName] = useState('Explorer');
  const [isEditingName, setIsEditingName] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  
  const [isPublishing, setIsPublishing] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const theme = THEMES[uiTheme];

  useEffect(() => {
    const savedAvatar = localStorage.getItem('beni_user_avatar');
    if (savedAvatar) setUserAvatar(savedAvatar);
    const savedName = localStorage.getItem('beni_user_name');
    if (savedName) setUserName(savedName);
    const savedTheme = localStorage.getItem('beni_ui_theme') as UITheme;
    if (savedTheme && THEMES[savedTheme]) setUiTheme(savedTheme);

    const saved = localStorage.getItem('beni_chats');
    if (saved) {
      try {
        const parsed: ChatThread[] = JSON.parse(saved);
        setThreads(parsed);
        if (parsed.length > 0) {
          setActiveThreadId(parsed[0].id);
          setMessages(parsed[0].messages);
          const room = SCIENCE_ROOMS.find(r => r.id === parsed[0].roomId);
          if (room) {
            setActiveRoom(room);
            setCurrentExpertPersona(room.expertPersona);
          }
        } else {
          startNewChat();
        }
      } catch (e) {
        startNewChat();
      }
    } else {
      startNewChat();
    }
  }, []);

  useEffect(() => {
    if (lastError) {
      const timer = setTimeout(() => setLastError(null), 6000);
      return () => clearTimeout(timer);
    }
  }, [lastError]);

  const updateAvatar = (avatar: string) => {
    setUserAvatar(avatar);
    localStorage.setItem('beni_user_avatar', avatar);
    setShowAvatarPicker(false);
  };

  const updateTheme = (newTheme: UITheme) => {
    setUiTheme(newTheme);
    localStorage.setItem('beni_ui_theme', newTheme);
  };

  const saveName = () => {
    localStorage.setItem('beni_user_name', userName);
    setIsEditingName(false);
  };

  useEffect(() => {
    if (!activeThreadId) return;
    
    const updatedThreads = threads.map(t => 
      t.id === activeThreadId 
        ? { ...t, messages, lastUpdated: Date.now(), roomId: activeRoom.id } 
        : t
    );

    const exists = threads.find(t => t.id === activeThreadId);
    let finalThreads = updatedThreads;
    if (!exists && messages.length > 0 && messages[0].id !== 'welcome') {
      const newThread: ChatThread = {
        id: activeThreadId,
        title: messages[0].role === 'user' ? messages[0].content.slice(0, 40) + '...' : 'New Discovery',
        messages,
        lastUpdated: Date.now(),
        roomId: activeRoom.id
      };
      finalThreads = [newThread, ...threads];
    }

    setThreads(finalThreads);
    localStorage.setItem('beni_chats', JSON.stringify(finalThreads));
  }, [messages, activeThreadId, activeRoom]);

  const startNewChat = (room?: ScienceRoom, persona?: string) => {
    const selectedRoom = room || activeRoom;
    const newId = Date.now().toString();
    setActiveThreadId(newId);
    setActiveRoom(selectedRoom);
    setMessages([{
      id: 'welcome',
      role: 'assistant',
      content: `Welcome to the ${selectedRoom.name}. I'm Beni. ${selectedRoom.description} What scientific mystery shall we unravel?`,
      timestamp: Date.now()
    }]);
    setShowHistory(false);
  };

  const handleRoomChange = (room: ScienceRoom) => {
    if (room.id === activeRoom.id) return;
    setCurrentExpertPersona(room.expertPersona);
    startNewChat(room, room.expertPersona);
  };

  const handlePersonaChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const personaValue = e.target.value;
    setCurrentExpertPersona(personaValue);
    startNewChat(activeRoom, personaValue);
  };

  const loadThread = (thread: ChatThread) => {
    setActiveThreadId(thread.id);
    setMessages(thread.messages);
    const room = SCIENCE_ROOMS.find(r => r.id === thread.roomId);
    if (room) {
      setActiveRoom(room);
      setCurrentExpertPersona(room.expertPersona);
    }
    setShowHistory(false);
  };

  const deleteThread = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = threads.filter(t => t.id !== id);
    setThreads(updated);
    localStorage.setItem('beni_chats', JSON.stringify(updated));
    if (activeThreadId === id) {
      if (updated.length > 0) loadThread(updated[0]);
      else startNewChat();
    }
  };

  const startRename = (e: React.MouseEvent, thread: ChatThread) => {
    e.stopPropagation();
    setRenamingThreadId(thread.id);
    setRenameInput(thread.title);
  };

  const saveRename = (e: React.FormEvent | React.FocusEvent) => {
    e.preventDefault();
    if (!renamingThreadId) return;

    const updated = threads.map(t => 
      t.id === renamingThreadId ? { ...t, title: renameInput } : t
    );
    setThreads(updated);
    localStorage.setItem('beni_chats', JSON.stringify(updated));
    setRenamingThreadId(null);
  };

  const startEdit = (m: Message) => {
    setEditingMessageId(m.id);
    setEditInput(m.content);
  };

  const saveEdit = () => {
    if (!editingMessageId) return;
    setMessages(prev => prev.map(m => 
      m.id === editingMessageId ? { ...m, content: editInput } : m
    ));
    setEditingMessageId(null);
  };

  const cancelEdit = () => {
    setEditingMessageId(null);
  };

  const handlePublish = (message: Message) => {
    setIsPublishing(message.id);
    const newPost: CommunityPost = {
      id: Date.now().toString(),
      userId: 'user-1',
      userName: userName,
      userAvatar: userAvatar,
      roomId: activeRoom.id,
      title: activeRoom.name + ' Insight',
      content: message.content.slice(0, 300) + (message.content.length > 300 ? '...' : ''),
      imageUrl: message.imageUrl,
      timestamp: Date.now(),
      upvotes: 0,
      tags: [activeRoom.id, 'Research']
    };
    const saved = localStorage.getItem('beni_community_posts');
    const posts = saved ? JSON.parse(saved) : [];
    localStorage.setItem('beni_community_posts', JSON.stringify([newPost, ...posts]));
    setTimeout(() => setIsPublishing(null), 2000);
  };

  const handleSend = async (e?: React.FormEvent, overrideText?: string) => {
    if (e) e.preventDefault();
    const textToSend = overrideText || input;
    if (!textToSend.trim() || isLoading) return;
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: textToSend, timestamp: Date.now() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setLastError(null);
    try {
      const response = await getScienceResponse(textToSend, currentExpertPersona);
      const assistantMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: response || "I'm sorry, I couldn't process that.", timestamp: Date.now() };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error: any) {
      setLastError("System connection disrupted.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleVisualize = async () => {
    if (!input.trim() || isLoading) return;
    const concept = input;
    setInput('');
    setIsLoading(true);
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: `Visualize: ${concept}`, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    try {
      const result = await generateSciVisual(concept);
      const assistantMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: result.explanation, type: 'image', imageUrl: result.imageUrl, timestamp: Date.now() };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      setLastError("Visual engine error.");
    } finally {
      setIsLoading(false);
    }
  };

  const filteredThreads = threads.filter(t => 
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    SCIENCE_ROOMS.find(r => r.id === t.roomId)?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`flex h-full w-full relative transition-all duration-700 ${theme.bg}`} style={{ backgroundImage: `radial-gradient(circle at top right, ${activeRoom.glowColor}, transparent)` }}>
      
      {lastError && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[60] w-full max-sm px-4 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="bg-red-500/10 backdrop-blur-md border border-red-500/30 rounded-3xl p-4 flex items-center gap-3 shadow-2xl">
            <div className="bg-red-500 rounded-full p-2 shrink-0">
              <ExclamationTriangleIcon className="w-4 h-4 text-white" />
            </div>
            <p className="text-sm text-red-100 font-bold">{lastError}</p>
          </div>
        </div>
      )}

      {/* History Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-[85%] sm:w-80 backdrop-blur-2xl transition-all duration-500 lg:relative lg:translate-x-0
        ${theme.sidebar} ${theme.border} border-r shadow-2xl lg:shadow-none
        ${showHistory ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex flex-col h-full">
          <div className={`p-6 border-b flex items-center justify-between ${theme.border}`}>
            <h3 className={`font-black uppercase tracking-[0.2em] text-[11px] flex items-center gap-2 ${theme.text}`}>
              <ClockIcon className="w-4 h-4" />
              History
            </h3>
            <button onClick={() => setShowHistory(false)} className={`lg:hidden p-2 bg-slate-800/20 rounded-full ${theme.textMuted}`}>
              <XMarkIcon className="w-5 h-5" />
            </button>
          </div>

          <div className="p-4 space-y-3">
            <button 
              onClick={() => startNewChat()}
              className={`w-full flex items-center justify-center gap-3 py-4 rounded-2xl transition-all font-black text-[11px] uppercase tracking-widest border shadow-lg active:scale-95 ${uiTheme === 'solstice' ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-900' : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-100'}`}
            >
              <PlusIcon className="w-5 h-5" />
              New session
            </button>

            {/* Thread Search Bar */}
            <div className="relative group">
              <input 
                type="text"
                placeholder="Search archives..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full py-3 pl-10 pr-4 rounded-xl text-xs font-bold focus:outline-none border transition-all ${
                  uiTheme === 'solstice' 
                    ? 'bg-slate-100 border-slate-200 focus:bg-white text-slate-700' 
                    : 'bg-slate-950/40 border-slate-800 focus:border-blue-500/50 text-slate-300'
                }`}
              />
              <MagnifyingGlassIcon className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors ${uiTheme === 'solstice' ? 'text-slate-400' : 'text-slate-600 group-focus-within:text-blue-500'}`} />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 rounded-full hover:bg-slate-800"
                >
                  <XMarkIcon className="w-3 h-3 text-slate-500" />
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar px-3 space-y-2">
            {filteredThreads.length > 0 ? (
              filteredThreads.map(t => {
                const r = SCIENCE_ROOMS.find(room => room.id === t.roomId);
                const isRenaming = renamingThreadId === t.id;

                return (
                  <div 
                    key={t.id}
                    onClick={() => !isRenaming && loadThread(t)}
                    className={`group flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all active:scale-95 ${
                      activeThreadId === t.id 
                        ? (uiTheme === 'solstice' ? 'bg-blue-50 border border-blue-200' : 'bg-slate-800 border border-slate-700') 
                        : 'hover:bg-slate-800/40 text-slate-500'
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <span className="text-xl shrink-0">{r?.icon || '🔬'}</span>
                      <div className="min-w-0 flex-1">
                        {isRenaming ? (
                          <form onSubmit={saveRename} className="flex items-center">
                            <input
                              autoFocus
                              value={renameInput}
                              onChange={(e) => setRenameInput(e.target.value)}
                              onBlur={saveRename}
                              className={`w-full bg-transparent border-b-2 border-blue-500 text-sm font-bold focus:outline-none ${activeThreadId === t.id ? (uiTheme === 'solstice' ? 'text-blue-700' : 'text-slate-100') : ''}`}
                            />
                          </form>
                        ) : (
                          <>
                            <p className={`text-sm font-bold truncate ${activeThreadId === t.id ? (uiTheme === 'solstice' ? 'text-blue-700' : 'text-slate-100') : ''}`}>{t.title}</p>
                            <p className={`text-[9px] uppercase font-black tracking-widest opacity-50`}>{r?.name}</p>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {!isRenaming && (
                        <>
                          <button 
                            onClick={(e) => startRename(e, t)}
                            className="p-2 opacity-100 lg:opacity-0 group-hover:opacity-100 hover:text-blue-400 transition-opacity"
                          >
                            <PencilSquareIcon className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={(e) => deleteThread(e, t.id)}
                            className="p-2 opacity-100 lg:opacity-0 group-hover:opacity-100 hover:text-red-400 transition-opacity"
                          >
                            <TrashIcon className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center">
                <p className={`text-xs font-bold uppercase tracking-widest ${theme.textMuted} opacity-40`}>No archives found</p>
              </div>
            )}
          </div>

          {/* Theme & Profile (Condensed for Sidebar) */}
          <div className={`p-6 border-t ${theme.border} space-y-6`}>
             <div className="flex justify-between items-center">
                <span className={`text-[10px] font-black uppercase tracking-widest ${theme.textMuted}`}>UI Config</span>
                <div className="flex gap-2">
                  {(Object.keys(THEMES) as UITheme[]).map((tId) => (
                    <button
                      key={tId}
                      onClick={() => updateTheme(tId)}
                      className={`w-6 h-6 rounded-full border-2 transition-all ${uiTheme === tId ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-slate-900 scale-110' : 'opacity-50'}`}
                      style={{ backgroundColor: tId === 'midnight' ? '#0f172a' : tId === 'solstice' ? '#f8fafc' : tId === 'event-horizon' ? '#000' : '#050a05' }}
                    />
                  ))}
                </div>
             </div>
             <div className="flex items-center gap-4 bg-slate-800/30 p-3 rounded-[2rem] border border-slate-800/50">
                <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center text-xl">{userAvatar}</div>
                <div className="min-w-0 flex-1">
                  <p className={`text-xs font-bold truncate ${theme.text}`}>{userName}</p>
                  <p className="text-[8px] uppercase font-black tracking-widest text-slate-600">Active Node</p>
                </div>
             </div>
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative">
        <header className={`p-4 sm:p-6 border-b backdrop-blur-md z-10 transition-colors duration-500 ${theme.header} ${theme.border}`}>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <button onClick={() => setShowHistory(true)} className={`p-3 rounded-2xl lg:hidden active:scale-90 ${uiTheme === 'solstice' ? 'bg-slate-100 text-slate-600' : 'bg-slate-800 text-slate-400'}`}>
                <Bars3Icon className="w-5 h-5" />
              </button>
              <div>
                <h2 className={`font-black text-xl flex items-center gap-3 ${theme.text}`}>
                  <span className="text-3xl">{activeRoom.icon}</span>
                  {activeRoom.name}
                </h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <p className={`text-[9px] uppercase tracking-[0.2em] font-black ${theme.textMuted}`}>Scientific Stream Active</p>
                </div>
              </div>
            </div>
            <div className={`hidden sm:flex items-center gap-3 px-4 py-2 rounded-full border ${uiTheme === 'solstice' ? 'bg-slate-100 border-slate-200' : 'bg-slate-900/50 border-slate-800'}`}>
               <span className={`text-[10px] font-black uppercase tracking-widest ${theme.textMuted}`}>ID: {activeRoom.id.toUpperCase()}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 px-1">
            {SCIENCE_ROOMS.map((room) => (
              <button
                key={room.id}
                onClick={() => handleRoomChange(room)}
                className={`flex-shrink-0 flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-black transition-all border whitespace-nowrap active:scale-95 ${
                  activeRoom.id === room.id 
                    ? `bg-gradient-to-r ${room.color} text-white border-transparent shadow-lg shadow-blue-500/10` 
                    : (uiTheme === 'solstice' ? 'bg-white text-slate-500 border-slate-200' : 'bg-slate-900 text-slate-400 border-slate-800')
                }`}
              >
                <span>{room.icon}</span>
                {room.name}
              </button>
            ))}
          </div>
        </header>

        <div className="flex-1 overflow-hidden flex flex-col max-w-5xl mx-auto w-full px-4 sm:px-8 py-6">
          <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-10 pr-2 no-scrollbar mb-4 pb-12">
            {messages.map((m) => (
              <div key={m.id} className={`flex gap-4 sm:gap-6 ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
                <div className="flex flex-col items-center gap-2 shrink-0">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl shadow-xl border overflow-hidden ${m.role === 'user' ? (uiTheme === 'solstice' ? 'bg-white border-slate-200' : 'bg-slate-800 border-slate-700') : (uiTheme === 'solstice' ? 'bg-indigo-50 border-indigo-100' : 'bg-slate-900 border-slate-800 ring-4 ring-indigo-500/10')}`}>
                    {m.role === 'user' ? userAvatar : <BeniIcon color={activeRoom.glowColor} size="w-full h-full" />}
                  </div>
                  <span className={`text-[8px] uppercase font-black tracking-widest ${m.role === 'user' ? theme.textMuted : 'text-indigo-400'}`}>
                    {m.role === 'user' ? userName.split(' ')[0] : 'BENI'}
                  </span>
                </div>

                <div className={`w-full max-w-[90%] sm:max-w-[80%] relative group rounded-3xl px-6 py-5 shadow-2xl transition-all duration-500 border ${
                    m.role === 'user' ? `${theme.bubbleUser} ${theme.text} ${theme.border}` : `${theme.bubbleAssistant} backdrop-blur-md ${theme.border} ${theme.text}`
                  }`}
                  style={m.role === 'assistant' && uiTheme !== 'solstice' ? { borderColor: activeRoom.glowColor } : {}}
                >
                  {/* Persistent Actions for Mobile */}
                  <div className={`absolute -top-3 flex items-center gap-2 ${m.role === 'user' ? '-left-2' : '-right-2'} transition-opacity group-hover:opacity-100 opacity-100 sm:opacity-0`}>
                    {m.role === 'user' && editingMessageId !== m.id && (
                      <button onClick={() => startEdit(m)} className={`p-2 rounded-full shadow-2xl transition-all border ${uiTheme === 'solstice' ? 'bg-white border-slate-200 text-slate-400' : 'bg-slate-900 border-slate-800 text-slate-500'}`}>
                        <PencilSquareIcon className="w-4 h-4" />
                      </button>
                    )}
                    {m.role === 'assistant' && m.id !== 'welcome' && (
                      <button onClick={() => handlePublish(m)} className={`p-2 rounded-full shadow-2xl transition-all hover:bg-indigo-600 ${isPublishing === m.id ? 'bg-emerald-600 scale-125' : (uiTheme === 'solstice' ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800')}`}>
                        <ShareIcon className={`w-4 h-4 ${isPublishing === m.id ? 'text-white' : 'text-indigo-400'}`} />
                      </button>
                    )}
                  </div>

                  {m.imageUrl && (
                    <div className={`mb-5 overflow-hidden rounded-2xl border-4 shadow-2xl transition-transform hover:scale-[1.02] active:scale-100 ${theme.border}`}>
                      <img src={m.imageUrl} alt="Visualization" className="w-full h-auto object-cover" />
                    </div>
                  )}

                  {editingMessageId === m.id ? (
                    <div className="space-y-4">
                      <textarea value={editInput} onChange={(e) => setEditInput(e.target.value)} className={`w-full p-4 rounded-2xl border focus:outline-none min-h-[120px] text-sm resize-none ${theme.inputBg} ${theme.border} ${theme.text}`} autoFocus />
                      <div className="flex justify-end gap-3">
                        <button onClick={cancelEdit} className="text-xs font-black uppercase tracking-widest text-slate-500">Cancel</button>
                        <button onClick={saveEdit} className="px-6 py-2 text-xs font-black uppercase tracking-widest bg-emerald-600 text-white rounded-xl active:scale-95">Save</button>
                      </div>
                    </div>
                  ) : (
                    <div className={`prose prose-sm sm:prose-base break-words leading-relaxed ${uiTheme === 'solstice' ? 'prose-slate' : 'prose-invert'}`}>
                      {m.content}
                    </div>
                  )}
                  
                  <div className={`mt-3 text-[8px] opacity-30 font-black tracking-widest ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
                    {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4 animate-pulse">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center border overflow-hidden ${uiTheme === 'solstice' ? 'bg-indigo-50 border-indigo-100' : 'bg-slate-900 border-slate-800'}`}>
                  <BeniIcon color={activeRoom.glowColor} size="w-full h-full" />
                </div>
                <div className={`rounded-3xl px-6 py-5 flex items-center space-x-2 ${theme.bubbleAssistant} ${theme.border}`}>
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:-0.3s]"></div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-auto relative z-10">
             <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mb-4 pb-1 px-2">
                {activeRoom.hints.map(hint => (
                  <button key={hint} onClick={() => setInput(hint)} className={`whitespace-nowrap px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all active:scale-90 ${uiTheme === 'solstice' ? 'bg-white text-slate-500 border-slate-200' : 'bg-slate-900/50 text-slate-500 border-slate-800'}`}>
                    {hint}
                  </button>
                ))}
             </div>

            <form onSubmit={(e) => handleSend(e)} className="relative group">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Query ${activeRoom.name}...`}
                className={`w-full border rounded-[2rem] py-6 pl-8 pr-44 focus:outline-none transition-all placeholder:text-slate-600 backdrop-blur-2xl shadow-2xl ${theme.inputBg} ${theme.border} ${theme.text} ${isDictating ? 'ring-4 ring-blue-500/20' : ''}`}
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                <button type="button" onClick={handleVisualize} disabled={!input.trim() || isLoading} className={`p-3 rounded-2xl transition-all active:scale-90 ${!input.trim() || isLoading ? 'text-slate-600 opacity-50' : 'text-emerald-500 bg-emerald-500/10'}`}><PhotoIcon className="w-5 h-5" /></button>
                <button type="submit" disabled={!input.trim() || isLoading} className={`p-4 rounded-[1.5rem] transition-all shadow-xl active:scale-95 disabled:opacity-30 bg-gradient-to-br ${activeRoom.color} text-white`}><PaperAirplaneIcon className="w-5 h-5" /></button>
              </div>
            </form>
          </div>
          <p className={`text-[8px] text-center mt-6 uppercase tracking-[0.4em] font-black opacity-30 ${theme.textMuted}`}>Core Layer v3.0 // Neural Alignment Active</p>
        </div>
      </div>
      
      {showHistory && <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-30 lg:hidden" onClick={() => setShowHistory(false)} />}
    </div>
  );
};

export default ChatInterface;