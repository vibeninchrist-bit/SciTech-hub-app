
import React, { useState } from 'react';
import { generateSciVisual, analyzeLabData } from '../services/geminiService';
import { 
  ChartBarIcon, 
  PhotoIcon, 
  ArrowPathIcon,
  BeakerIcon
} from '@heroicons/react/24/outline';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const ScienceLab: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'visualize' | 'analyze'>('visualize');
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [visualResult, setVisualResult] = useState<{ url: string; text: string } | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  const handleAction = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    try {
      if (activeMode === 'visualize') {
        const res = await generateSciVisual(input);
        setVisualResult({ url: res.imageUrl, text: res.explanation });
      } else {
        const res = await analyzeLabData(input);
        setAnalysisResult(res);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="flex flex-col h-full max-w-7xl mx-auto w-full p-4 sm:p-8 md:p-12 overflow-y-auto no-scrollbar">
      <header className="mb-10 text-center sm:text-left">
        <h2 className="text-4xl font-black flex items-center justify-center sm:justify-start gap-4">
          <BeakerIcon className="w-10 h-10 text-emerald-500 drop-shadow-[0_0_15px_rgba(16,185,129,0.5)]" />
          The Science Lab
        </h2>
        <p className="text-slate-500 mt-3 text-lg font-medium">Synthesize visual concepts and dissect experimental data.</p>
      </header>

      <div className="flex flex-col lg:grid lg:grid-cols-12 gap-8 lg:items-stretch">
        {/* Control Panel */}
        <div className="lg:col-span-4 flex flex-col">
          <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-[2.5rem] p-8 shadow-2xl sticky top-0">
            <div className="flex bg-slate-800/50 p-1.5 rounded-2xl mb-8 border border-slate-800">
              <button 
                onClick={() => setActiveMode('visualize')}
                className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-3 transition-all font-bold text-sm ${
                  activeMode === 'visualize' ? 'bg-slate-700 text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                <PhotoIcon className="w-5 h-5" />
                Visualizer
              </button>
              <button 
                onClick={() => setActiveMode('analyze')}
                className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-3 transition-all font-bold text-sm ${
                  activeMode === 'analyze' ? 'bg-slate-700 text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                <ChartBarIcon className="w-5 h-5" />
                Analyzer
              </button>
            </div>

            <div className="space-y-6">
              <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-500">
                {activeMode === 'visualize' ? 'Synthesis Subject' : 'Data Transcription'}
              </label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={activeMode === 'visualize' ? "e.g. Quantum superposition in a vacuum" : "e.g. Spectral data for hydrogen emission..."}
                className="w-full h-48 bg-slate-950/50 border border-slate-800 rounded-3xl p-5 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/10 transition-all resize-none text-sm leading-relaxed"
              />
              <button
                onClick={handleAction}
                disabled={!input.trim() || loading}
                className="w-full py-5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 rounded-3xl font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center gap-3 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
              >
                {loading ? <ArrowPathIcon className="w-6 h-6 animate-spin" /> : 'Execute Sequence'}
              </button>
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-8 flex flex-col">
          <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-800 rounded-[3rem] p-8 sm:p-12 min-h-[500px] flex flex-col shadow-inner items-center justify-center relative overflow-hidden">
            {/* Background pattern */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#3b82f6 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

            {!loading && !visualResult && !analysisResult && (
              <div className="relative z-10 text-center space-y-6">
                <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto border border-slate-700 shadow-2xl">
                  <BeakerIcon className="w-12 h-12 text-slate-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-400 uppercase tracking-widest">Awaiting Input</h3>
                  <p className="text-slate-600 mt-2 text-sm max-w-xs mx-auto">Start a simulation sequence from the control panel to view results.</p>
                </div>
              </div>
            )}

            {loading && (
              <div className="relative z-10 text-center space-y-8">
                <div className="relative w-32 h-32 mx-auto">
                  <div className="absolute inset-0 border-[6px] border-emerald-500/10 rounded-full"></div>
                  <div className="absolute inset-0 border-[6px] border-t-emerald-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-4 border-[6px] border-b-blue-500 rounded-full animate-spin-slow"></div>
                </div>
                <div className="space-y-2">
                  <p className="text-emerald-400 font-black uppercase tracking-[0.3em] animate-pulse">Processing Synthesis...</p>
                  <p className="text-slate-600 text-xs font-mono">NODE_CLUSTER_STATUS: BUSY</p>
                </div>
              </div>
            )}

            {!loading && activeMode === 'visualize' && visualResult && (
              <div className="w-full relative z-10 animate-in fade-in zoom-in-95 duration-700">
                <div className="group rounded-[2rem] overflow-hidden border-4 border-slate-800 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
                  <img src={visualResult.url} alt="Science Result" className="w-full h-auto object-cover transform transition-transform duration-[2s] group-hover:scale-110" />
                </div>
                <div className="mt-8 p-8 bg-slate-950/60 rounded-[2rem] border border-slate-800 backdrop-blur-md">
                  <div className="flex items-center gap-3 mb-4">
                    <SparklesIcon className="w-5 h-5 text-emerald-400" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">A.I. Transcription</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed italic text-lg">{visualResult.text}</p>
                </div>
              </div>
            )}

            {!loading && activeMode === 'analyze' && analysisResult && (
              <div className="w-full flex-1 flex flex-col relative z-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
                <div className="flex items-center justify-between mb-10">
                  <h3 className="text-2xl font-black text-emerald-400 tracking-tight">{analysisResult.title}</h3>
                  <div className="px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[10px] font-black uppercase text-emerald-500 tracking-widest">Data Verified</div>
                </div>
                <div className="h-[300px] sm:h-[400px] w-full bg-slate-950/30 p-4 rounded-[2rem] border border-slate-800/50">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analysisResult.labels.map((l: string, i: number) => ({ name: l, val: analysisResult.values[i] }))}>
                      <CartesianGrid strokeDasharray="6 6" stroke="#1e293b" vertical={false} />
                      <XAxis dataKey="name" stroke="#64748b" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700 }} />
                      <YAxis stroke="#64748b" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700 }} />
                      <Tooltip cursor={{ fill: '#ffffff05' }} contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '16px', boxShadow: '0 10px 30px rgba(0,0,0,0.5)' }} />
                      <Bar dataKey="val" radius={[8, 8, 0, 0]}>
                         {analysisResult.values.map((_: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} fillOpacity={0.8} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-8 p-8 bg-slate-950/60 rounded-[2rem] border border-slate-800 shadow-xl">
                   <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4">Neural Analysis Summary</h4>
                   <p className="text-slate-200 text-lg leading-relaxed">{analysisResult.analysis}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Internal icons needed
const SparklesIcon = (props: any) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
);

export default ScienceLab;
