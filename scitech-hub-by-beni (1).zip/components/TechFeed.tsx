
import React, { useState, useEffect } from 'react';
import { getGroundedNews } from '../services/geminiService';
import { GroundingSource } from '../types';
import { MagnifyingGlassIcon, NewspaperIcon, LinkIcon } from '@heroicons/react/24/outline';

const TechFeed: React.FC = () => {
  const [query, setQuery] = useState('latest quantum computing news');
  const [news, setNews] = useState<string | null>(null);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchNews = async () => {
    setLoading(true);
    try {
      const data = await getGroundedNews(query);
      setNews(data.text);
      setSources(data.sources);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, []);

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto w-full p-6">
      <header className="mb-8">
        <h2 className="text-3xl font-bold flex items-center gap-2">
          <NewspaperIcon className="w-8 h-8 text-blue-400" />
          SciTech Feed
        </h2>
        <p className="text-slate-400">Grounded real-time updates on trending technology.</p>
      </header>

      <div className="relative mb-8">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && fetchNews()}
          placeholder="Search for tech breakthroughs..."
          className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-blue-500/50"
        />
        <MagnifyingGlassIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
      </div>

      <div className="flex-1 space-y-6 overflow-y-auto pr-2 no-scrollbar">
        {loading ? (
          <div className="space-y-4 animate-pulse">
            <div className="h-4 bg-slate-800 rounded w-3/4"></div>
            <div className="h-4 bg-slate-800 rounded w-full"></div>
            <div className="h-4 bg-slate-800 rounded w-5/6"></div>
          </div>
        ) : (
          <>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 prose prose-invert max-w-none">
              <h3 className="text-lg font-bold text-blue-400 mb-4 uppercase tracking-wider">Top Summary</h3>
              <p className="whitespace-pre-wrap">{news}</p>
            </div>

            {sources.length > 0 && (
              <div>
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4">Verification Sources</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {sources.map((source, idx) => (
                    <a
                      key={idx}
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-3 p-3 bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-xl transition-all group"
                    >
                      <div className="bg-slate-800 p-2 rounded-lg group-hover:bg-blue-500/10 transition-colors">
                        <LinkIcon className="w-4 h-4 text-slate-400 group-hover:text-blue-400" />
                      </div>
                      <span className="text-sm font-medium text-slate-300 truncate">{source.title}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default TechFeed;
