
import React, { useState, useEffect } from 'react';
import { CommunityPost, SCIENCE_ROOMS } from '../types';
import { 
  GlobeAltIcon, 
  ArrowUpIcon, 
  ArrowPathIcon,
  ShareIcon,
  SparklesIcon
} from '@heroicons/react/24/solid';

const SEED_POSTS: CommunityPost[] = [
  {
    id: 'seed-1',
    userId: 'bot-1',
    userName: 'QuantumEnthusiast',
    userAvatar: '⚛️',
    roomId: 'physics',
    title: 'Visualizing Entanglement',
    content: 'Just used the Beni visualizer to map out EPR pairs. The correlation between spin states is beautifully represented in this geometry!',
    upvotes: 42,
    timestamp: Date.now() - 3600000,
    tags: ['Quantum', 'Physics']
  },
  {
    id: 'seed-2',
    userId: 'bot-2',
    userName: 'BioHackerX',
    userAvatar: '🧬',
    roomId: 'biology',
    title: 'CRISPR Pathway Insight',
    content: 'Fascinating discussion with Beni about non-homologous end joining. We found a novel way to visualize the double-strand break repair process.',
    upvotes: 28,
    timestamp: Date.now() - 7200000,
    tags: ['CRISPR', 'Genetics']
  }
];

const DiscoveryFeed: React.FC = () => {
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load local storage posts + seed posts
    const loadData = () => {
      setLoading(true);
      const saved = localStorage.getItem('beni_community_posts');
      const userPosts = saved ? JSON.parse(saved) : [];
      setPosts([...userPosts, ...SEED_POSTS].sort((a, b) => b.timestamp - a.timestamp));
      setLoading(false);
    };
    
    loadData();
    // Simulate real-time updates every 30s
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleUpvote = (id: string) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, upvotes: p.upvotes + 1 } : p));
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto w-full p-6 overflow-hidden">
      <header className="mb-8 shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold flex items-center gap-2">
              <GlobeAltIcon className="w-8 h-8 text-indigo-400" />
              Scientific Discovery
            </h2>
            <p className="text-slate-400">Collaborative breakthroughs from the SciTech community.</p>
          </div>
          <div className="hidden sm:block">
            <div className="bg-indigo-900/20 border border-indigo-500/20 rounded-full px-4 py-1.5 flex items-center gap-2">
              <SparklesIcon className="w-4 h-4 text-indigo-400 animate-pulse" />
              <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-300">Live Exchange</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto pr-2 no-scrollbar space-y-6 pb-20 md:pb-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-full space-y-4">
             <ArrowPathIcon className="w-10 h-10 text-indigo-500 animate-spin" />
             <p className="text-indigo-400 font-mono text-xs uppercase tracking-widest">Syncing with Node...</p>
          </div>
        ) : (
          posts.map((post) => {
            const room = SCIENCE_ROOMS.find(r => r.id === post.roomId);
            return (
              <div 
                key={post.id} 
                className="group relative bg-slate-900/50 border border-slate-800 rounded-2xl p-6 transition-all hover:bg-slate-900 hover:border-slate-700 shadow-xl overflow-hidden"
              >
                {/* Visual Flair based on Room */}
                <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${room?.color || 'from-slate-500 to-slate-600'} opacity-[0.05] blur-2xl -translate-y-12 translate-x-12`}></div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-2xl shadow-inner border border-slate-700">
                    {post.userAvatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-100">{post.userName}</span>
                      <span className="text-slate-500 text-[10px]">•</span>
                      <span className="text-slate-500 text-[10px] font-mono">
                        {new Date(post.timestamp).toLocaleDateString()}
                      </span>
                      {room && (
                        <span className={`ml-auto px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-gradient-to-r ${room.color} text-white`}>
                          {room.name}
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-bold text-slate-200 mb-2 leading-tight">
                      {post.title}
                    </h3>
                    <p className="text-slate-400 text-sm leading-relaxed mb-4">
                      {post.content}
                    </p>
                    
                    {post.imageUrl && (
                      <div className="mb-4 rounded-xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
                        <img src={post.imageUrl} alt="Shared visualization" className="w-full object-cover max-h-64 opacity-90 hover:opacity-100 transition-opacity" />
                      </div>
                    )}

                    <div className="flex items-center gap-4">
                      <button 
                        onClick={() => handleUpvote(post.id)}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-indigo-600/20 text-slate-400 hover:text-indigo-400 transition-all border border-slate-700"
                      >
                        <ArrowUpIcon className="w-4 h-4" />
                        <span className="text-xs font-bold">{post.upvotes}</span>
                      </button>
                      <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600/20 text-slate-400 hover:text-emerald-400 transition-all border border-slate-700">
                        <ArrowPathIcon className="w-4 h-4" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Replicate</span>
                      </button>
                      <button className="p-2 rounded-lg text-slate-500 hover:text-slate-200 hover:bg-slate-800 transition-all">
                        <ShareIcon className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default DiscoveryFeed;
