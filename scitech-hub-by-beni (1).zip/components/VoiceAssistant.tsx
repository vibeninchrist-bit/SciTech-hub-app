
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { MicrophoneIcon, StopCircleIcon, SparklesIcon, SpeakerWaveIcon } from '@heroicons/react/24/outline';
import { getScienceResponse, getSpokenResponse } from '../services/geminiService';

const Waveform: React.FC<{ active: boolean; color: string }> = ({ active, color }) => {
  return (
    <div className="flex items-center justify-center space-x-1 h-12">
      {[...Array(12)].map((_, i) => (
        <div
          key={i}
          className={`w-1 rounded-full transition-all duration-300 ${color} ${
            active ? 'animate-waveform' : 'h-1'
          }`}
          style={{
            animationDelay: `${i * 0.1}s`,
            height: active ? '100%' : '4px',
          }}
        />
      ))}
      <style>{`
        @keyframes waveform {
          0%, 100% { height: 10px; }
          50% { height: 40px; }
        }
        .animate-waveform {
          animation: waveform 1s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

const VoiceAssistant: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState<'idle' | 'connecting' | 'listening' | 'processing' | 'speaking'>('idle');
  const [transcription, setTranscription] = useState('');
  const [scienceResponse, setScienceResponse] = useState('');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const inputTranscriptionRef = useRef('');
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext) => {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) {
      channelData[i] = dataInt16[i] / 32768.0;
    }
    return buffer;
  };

  const playSingleAudio = async (base64Audio: string) => {
    if (!audioContextRef.current) return;
    setStatus('speaking');
    const buffer = await decodeAudioData(decode(base64Audio), audioContextRef.current);
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    
    source.onended = () => {
      sourcesRef.current.delete(source);
      setStatus('listening');
    };

    source.start(0);
    sourcesRef.current.add(source);
  };

  const processScienceQuery = async (query: string) => {
    if (!query.trim()) return;
    setStatus('processing');
    setScienceResponse('');
    
    try {
      const expertText = await getScienceResponse(query);
      setScienceResponse(expertText);
      
      const audioData = await getSpokenResponse(expertText);
      if (audioData) {
        await playSingleAudio(audioData);
      } else {
        setStatus('listening');
      }
    } catch (err) {
      console.error("Science processing error:", err);
      setStatus('listening');
    }
  };

  const stopConversation = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    setIsActive(false);
    setStatus('idle');
    inputTranscriptionRef.current = '';
  }, []);

  const startConversation = async () => {
    setStatus('connecting');
    inputTranscriptionRef.current = '';
    setTranscription('');
    setScienceResponse('');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = audioCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const session = await ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: 'You are a scientific listener. Transcribe the users audio perfectly. Do not respond with audio yourself; just acknowledge the turn is complete so I can process the transcription through the Science Logic engine.',
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            setStatus('listening');
            setIsActive(true);
            
            const inputCtx = new AudioContext({ sampleRate: 16000 });
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              if (status === 'speaking' || status === 'processing') return;

              const input = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(input.length);
              for (let i = 0; i < input.length; i++) int16[i] = input[i] * 32768;
              
              const base64 = btoa(String.fromCharCode(...new Uint8Array(int16.buffer)));
              session.sendRealtimeInput({
                media: { data: base64, mimeType: 'audio/pcm;rate=16000' }
              });
            };

            source.connect(processor);
            processor.connect(inputCtx.destination);
          },
          onmessage: async (msg) => {
            if (msg.serverContent?.inputTranscription) {
              const text = msg.serverContent.inputTranscription.text;
              inputTranscriptionRef.current += text;
              setTranscription(inputTranscriptionRef.current);
            }

            if (msg.serverContent?.turnComplete) {
              const fullQuery = inputTranscriptionRef.current;
              if (fullQuery.trim()) {
                await processScienceQuery(fullQuery);
              }
              inputTranscriptionRef.current = '';
            }

            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
            }
          },
          onerror: (e) => {
            console.error("Live API Error:", e);
            stopConversation();
          },
          onclose: () => stopConversation()
        }
      });

      sessionRef.current = session;
    } catch (err) {
      console.error("Connection Error:", err);
      setStatus('idle');
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto w-full p-6 overflow-hidden bg-slate-950/50">
      <div className="text-center mb-4 shrink-0">
        <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent">
          Beni Voice Assistant
        </h2>
        <div className="flex items-center justify-center space-x-2">
           <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
           <p className="text-slate-500 text-[10px] uppercase tracking-[0.2em] font-bold">Scientific Core Active</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center space-y-12 overflow-y-auto no-scrollbar">
        {/* Dynamic Waveform Visualization */}
        <div className="w-full flex justify-center py-4">
          <Waveform 
            active={status === 'listening' || status === 'speaking'} 
            color={status === 'speaking' ? 'bg-indigo-400' : 'bg-blue-400'} 
          />
        </div>

        <div className="relative group">
          {/* Enhanced animated rings */}
          {isActive && (
            <div className="absolute inset-0 -m-16 flex items-center justify-center pointer-events-none">
              <div className={`absolute w-56 h-56 border-2 border-blue-500/10 rounded-full animate-ping duration-1000 ${status === 'listening' ? 'opacity-100' : 'opacity-0'}`}></div>
              <div className={`absolute w-48 h-48 border border-indigo-500/20 rounded-full animate-pulse ${status === 'speaking' ? 'opacity-100' : 'opacity-0'}`}></div>
              <div className={`absolute w-40 h-40 border-4 border-t-amber-500/40 border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin ${status === 'processing' ? 'opacity-100' : 'opacity-0'}`}></div>
            </div>
          )}
          
          <button
            onClick={isActive ? stopConversation : startConversation}
            disabled={status === 'connecting'}
            className={`relative z-10 w-32 h-32 rounded-full flex flex-col items-center justify-center transition-all duration-500 shadow-2xl overflow-hidden group/btn ${
              isActive 
                ? (status === 'speaking' ? 'bg-indigo-600 shadow-indigo-500/40' : status === 'processing' ? 'bg-amber-600 shadow-amber-500/40' : 'bg-red-500 shadow-red-500/40') 
                : 'bg-gradient-to-br from-blue-600 to-indigo-700 hover:scale-105 shadow-blue-500/30'
            }`}
          >
            {/* Glossy overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent pointer-events-none"></div>
            
            {isActive ? (
              status === 'processing' ? (
                <SparklesIcon className="w-12 h-12 text-white animate-pulse" />
              ) : status === 'speaking' ? (
                <SpeakerWaveIcon className="w-12 h-12 text-white animate-bounce" />
              ) : (
                <StopCircleIcon className="w-14 h-14 text-white" />
              )
            ) : (
              <MicrophoneIcon className="w-14 h-14 text-white group-hover/btn:scale-110 transition-transform" />
            )}
            
            <span className="absolute bottom-4 text-[9px] uppercase tracking-widest font-black text-white/50">
              {status}
            </span>
          </button>
        </div>

        <div className="w-full space-y-8 max-w-2xl px-4 pb-12">
          {transcription && (
            <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center justify-center space-x-2">
                <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-blue-500/30"></div>
                <p className="text-[10px] text-blue-400 font-black uppercase tracking-[0.3em]">Audio Input Detected</p>
                <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-blue-500/30"></div>
              </div>
              <div className="p-5 bg-slate-900/60 border border-blue-500/20 rounded-2xl text-center backdrop-blur-md shadow-xl">
                <p className="text-slate-100 text-xl font-medium leading-relaxed italic">
                  "{transcription}"
                </p>
              </div>
            </div>
          )}

          {status === 'processing' && (
            <div className="flex flex-col items-center space-y-4 py-6">
              <div className="relative">
                <div className="w-12 h-12 border-4 border-amber-500/20 rounded-full"></div>
                <div className="absolute inset-0 w-12 h-12 border-4 border-t-amber-500 rounded-full animate-spin"></div>
              </div>
              <p className="text-xs text-amber-400 font-mono uppercase tracking-widest animate-pulse">Accessing Science Database...</p>
            </div>
          )}

          {scienceResponse && (
            <div className="space-y-4 animate-in fade-in zoom-in-95 slide-in-from-bottom-8 duration-700">
              <div className="flex items-center justify-center space-x-2">
                <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-indigo-500/30"></div>
                <p className="text-[10px] text-indigo-400 font-black uppercase tracking-[0.3em]">Beni's Response</p>
                <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-indigo-500/30"></div>
              </div>
              <div className="p-8 bg-indigo-950/20 border border-indigo-500/20 rounded-[2.5rem] shadow-2xl relative overflow-hidden backdrop-blur-md group">
                <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl"></div>
                <div className="prose prose-invert prose-sm max-w-none text-slate-200 leading-relaxed text-lg">
                  {scienceResponse}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {!isActive && status === 'idle' && (
        <div className="mt-auto p-6 flex flex-col items-center space-y-4 shrink-0 border-t border-slate-900">
          <p className="text-[10px] text-slate-600 uppercase tracking-widest font-bold">Suggested Labs</p>
          <div className="flex flex-wrap justify-center gap-3">
            {["Quantum Entanglement", "Gene Editing", "Neural Networks"].map(hint => (
              <button 
                key={hint} 
                onClick={() => { setTranscription(hint); startConversation(); }}
                className="px-4 py-2 bg-slate-900/50 border border-slate-800 hover:border-blue-500/50 hover:bg-slate-800 rounded-xl text-[11px] text-slate-400 transition-all hover:text-blue-300"
              >
                {hint}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceAssistant;
